<style>
    h1 {
        text-align: center;
    }
    html {
        margin-left: 10em;
        margin-right: 10em;
    }
    div {
        text-align:center;
    }
</style>