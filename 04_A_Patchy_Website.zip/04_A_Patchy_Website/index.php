<?php
include_once "prehead.php";
$_SESSION['Page'] = 'Home';
include_once "header.php";
?>


<br/>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc posuere, leo at fermentum dapibus, justo nulla vestibulum eros, sed mollis turpis leo auctor ante. Nunc vitae lectus id tortor laoreet egestas. Pellentesque sollicitudin, diam vel malesuada mattis, justo lacus aliquet ex, nec porta leo massa nec neque. Nulla dignissim, urna quis sodales posuere, erat nunc euismod ante, ac porttitor diam nisl sed purus. Fusce efficitur consequat metus eget accumsan. Curabitur cursus urna in orci vehicula accumsan. Duis ex ante, auctor nec elementum et, accumsan et lorem. Praesent placerat efficitur nisi rutrum placerat.
<br/><br/>
Fusce pretium ante urna, vitae tincidunt velit euismod malesuada. Vestibulum convallis ligula eget vehicula fringilla. Donec quam erat, finibus ac metus at, varius fringilla nibh. Donec eu tempus neque, id iaculis est. Integer lorem nisi, efficitur vel hendrerit id, vulputate ac nisl. Curabitur consequat dictum tellus vitae fermentum. Aenean ac convallis turpis. Nulla iaculis eu risus et dapibus. Aliquam eu placerat ex. Nullam in purus vitae turpis vulputate interdum non vitae odio. Curabitur non turpis ipsum.
<br/><br/>
Donec molestie, tellus nec porttitor dapibus, ligula elit convallis ex, a placerat ipsum leo sit amet magna. Pellentesque posuere sapien et pulvinar tempus. Nullam vel ipsum dolor. Aliquam erat volutpat. Morbi quis gravida nisi. Donec nec libero aliquet, venenatis urna ac, condimentum enim. Nullam aliquam vel eros et gravida. Maecenas nec justo auctor, aliquet ante ut, ultricies metus.
<br/><br/>
Donec volutpat sodales velit, ut bibendum eros ultrices sed. In ante neque, pulvinar ut ante eget, placerat eleifend metus. Aliquam pharetra, dui accumsan facilisis aliquam, diam libero mollis eros, vitae eleifend ipsum orci a arcu. Aenean pellentesque id felis efficitur molestie. Nam elementum, mi at vehicula sodales, lorem mauris iaculis quam, vel pellentesque leo risus eget sapien. Curabitur eget ornare tortor. Praesent mollis orci nec dapibus tempus. Quisque ornare ante odio, ut tempor elit vehicula nec. Duis scelerisque eros accumsan nibh maximus ullamcorper.
<br/><br/>
Aliquam vitae faucibus tortor, sagittis ultricies ante. Morbi sed laoreet enim, non blandit tortor. Curabitur vitae lobortis ante. Vestibulum laoreet sem ante, nec fermentum justo viverra condimentum. Maecenas dui quam, bibendum eu dapibus ac, pharetra in metus. Praesent venenatis enim ac fringilla congue. Integer auctor tellus sollicitudin feugiat feugiat. Curabitur id dapibus lorem. Mauris accumsan ultrices justo eu dignissim. 

<?php
include_once "footer.php";
?>