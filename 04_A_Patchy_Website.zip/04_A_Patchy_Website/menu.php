<?php
?>
<div>
    <a href="index.php">Home</a> -
    <a href="page1.php">About</a> -
    <a href="page2.php">Locations</a>
</div>

